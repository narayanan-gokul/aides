# Aides

A python package consisting of some helper methods from various packages.
Managed using `pyenv` and `poetry`
